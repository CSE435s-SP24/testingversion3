package hw1;

public enum Type {
	INT,
	STRING
}
