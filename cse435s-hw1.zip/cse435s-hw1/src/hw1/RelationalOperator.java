package hw1;

public enum RelationalOperator {
	GT,
	LT,
	EQ,
	GTE,
	LTE,
	NOTEQ
	

}
